﻿using System;
using System.Collections.Generic;

namespace DFS
{
    public class Vertex
    {
        public String data;
        public bool visited; // чи проходили вершину
        public Vertex(String data, bool visited)
        {
            this.data = data;
            this.visited = visited;
        }
    }
    public class Graph
    {
        private int maxVertexSize; // розмір 2-вимірного масиву
        private int size; // розмір поточної вершини
        private Vertex[] vertexs;
        private int[,] adjacencyMatrix;
        private Stack<Int32> stack;// занесення поточних вершин в стек
        public Graph(int maxVertexSize)
        {
            this.maxVertexSize = maxVertexSize;
            vertexs = new Vertex[maxVertexSize];
            adjacencyMatrix = new int[maxVertexSize,
            maxVertexSize];
            stack = new Stack<Int32>();
        }
        public void AddVertex(String data)
        {
            Vertex vertex = new Vertex(data, false);
            vertexs[size] = vertex;
            size++;
        }
        // додати суміжні ребра
        public void AddEdge(int from, int to)
        {
            // A -> B != B -> A
            adjacencyMatrix[from, to] = 1;
        }
        public void DepthFirstSearch()
        {
            // почати пошук з першої вершини 
            Vertex firstVertex = vertexs[0];
            firstVertex.visited = true;
            Console.Write(firstVertex.data);
            stack.Push(0);
            while (stack.Count > 0)
            {
                int row = stack.Peek();
                // отримати позиції суміжних не відвіданих вершин
                int col = FindAdjacencyUnVisitedVertex(row);
                if (col == -1)
                {
                    stack.Pop();
                }
                else
                {
                    vertexs[col].visited = true;
                    Console.Write(" -> " + vertexs[col].data);
                    stack.Push(col);
                }
            }
            Clear();
        }
        // отримати позиції суміжних не відвіданих вершин
        public int FindAdjacencyUnVisitedVertex(int row)
        {
            for (int col = 0; col < size; col++)
            {
                if (adjacencyMatrix[row, col] == 1 &&
                !vertexs[col].visited)
                {
                    return col;
                }
            }
            return -1;
        }
        public void Clear()
        {
            for (int i = 0; i < size; i++)
            {
                vertexs[i].visited = false;
            }
        }
        public int[,] GetAdjacencyMatrix()
        {
            return adjacencyMatrix;
        }
        public Vertex[] GetVertexs()
        {
            return vertexs;
        }
    }

    public class Program
    {
        public static void Main(String[] args)
        {
            Graph graph = new Graph(5);
            graph.AddVertex("A");
            graph.AddVertex("B");
            graph.AddVertex("C");
            graph.AddVertex("D");
            graph.AddVertex("E");
            graph.AddEdge(0, 1);
            graph.AddEdge(0, 2);
            graph.AddEdge(0, 3);
            graph.AddEdge(1, 2);
            graph.AddEdge(1, 3);
            graph.AddEdge(2, 3);
            graph.AddEdge(3, 4);
            // Двовимірний обхід масиву, вихідне ребро та сусідній масив 
            PrintGraph(graph);
            Console.Write("\nDepth-first search traversal output : \n");
            graph.DepthFirstSearch();
            Console.ReadLine();
        }
        public static void PrintGraph(Graph graph)
        {
            Console.Write("Two-dimensional array traversal vertex edge and adjacent array: \n ");
            for (int i = 0; i < graph.GetVertexs().Length; i++)
            {
                Console.Write(graph.GetVertexs()[i].data + " ");
            }
            Console.Write("\n");
            for (int i = 0; i < graph.GetAdjacencyMatrix().GetLength(0);
            i++)
            {
                Console.Write(graph.GetVertexs()[i].data + " ");
                for (int j = 0; j <
                graph.GetAdjacencyMatrix().GetLength(0); j++)
                {
                    Console.Write(graph.GetAdjacencyMatrix()[i, j] + " ");
                }
                Console.Write("\n");
            }
        }
    }
}
